import { useState, useEffect } from "react";
import { Mail, Instagram, Send, Camera, Users, Target } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Index() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [inView, setInView] = useState<Record<string, boolean>>({});
  const [activeSection, setActiveSection] = useState("hero");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const observers: Record<string, IntersectionObserver> = {};

    const sections = ["hero", "about", "portfolio", "why-work", "contact"];
    sections.forEach((section) => {
      const element = document.getElementById(section);
      if (element) {
        observers[section] = new IntersectionObserver(
          ([entry]) => {
            if (entry.isIntersecting) {
              setInView((prev) => ({ ...prev, [section]: true }));
              setActiveSection(section);
            }
          },
          { threshold: 0.2 },
        );
        observers[section].observe(element);
      }
    });

    return () => {
      Object.values(observers).forEach((observer) => observer.disconnect());
    };
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  const portfolioItems = [
    {
      id: 1,
      title: "Game Action",
      category: "Live Competition",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2F0ff0091125f74cfc86195076ada5223d",
    },
    {
      id: 2,
      title: "Victory Emotion",
      category: "Celebration Moments",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2Ff8bf5bf66bc14468b24e61076a69fd3f",
    },
    {
      id: 3,
      title: "Team Spirit",
      category: "Bench Moments",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2Fac7527b1e5b04e659e29c58a05115d56",
    },
    {
      id: 4,
      title: "Ice Portrait",
      category: "Player Focus",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2Fc91f939c3a0b4295819745e8bd8ffb4a",
    },
    {
      id: 5,
      title: "Intense Moment",
      category: "Game Action",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2F6579aedc10bc41dba77462f7bf1ca6f9",
    },
    {
      id: 6,
      title: "Leadership",
      category: "Captain Moments",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2Ff581923806024426b3d7991ba1da2bbe",
    },
  ];

  const whyWorkItems = [
    {
      icon: <Camera className="w-8 h-8" />,
      title: "Deep Hockey Knowledge",
      description:
        "I understand the sport—the intensity, the strategy, and the raw emotion that unfolds on the ice.",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Live Tournament Experience",
      description:
        "Years of shooting live games and tournaments mean I capture authentic moments when it matters most.",
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Women's Hockey Focus",
      description:
        "I specialize in women's hockey, telling stories that deserve to be seen and celebrated.",
    },
    {
      icon: <Send className="w-8 h-8" />,
      title: "Social-Ready Visuals",
      description:
        "Powerful images optimized for social media that engage your audience and tell your team's story.",
    },
  ];

  return (
    <div className="w-full bg-white text-slate-900">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between md:px-12">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => scrollToSection("hero")}
              className="text-xl md:text-2xl font-black text-slate-900 hover:text-blue-600 transition-colors"
            >
              Maria Mikaelyan
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {[
              { id: "hero", label: "Home" },
              { id: "about", label: "About" },
              { id: "portfolio", label: "Portfolio" },
              { id: "why-work", label: "Why Me" },
              { id: "contact", label: "Contact" },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={cn(
                  "font-semibold transition-colors duration-300 relative",
                  activeSection === item.id
                    ? "text-blue-600"
                    : "text-slate-700 hover:text-blue-600",
                )}
              >
                {item.label}
                {activeSection === item.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
                )}
              </button>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden flex flex-col gap-1.5 p-2"
            aria-label="Toggle menu"
          >
            <span
              className={cn(
                "w-6 h-0.5 bg-slate-900 transition-all",
                mobileMenuOpen && "transform rotate-45 translate-y-2",
              )}
            />
            <span
              className={cn(
                "w-6 h-0.5 bg-slate-900 transition-all",
                mobileMenuOpen && "opacity-0",
              )}
            />
            <span
              className={cn(
                "w-6 h-0.5 bg-slate-900 transition-all",
                mobileMenuOpen && "transform -rotate-45 -translate-y-2",
              )}
            />
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden bg-white border-t border-slate-200 px-6 py-4">
            <div className="flex flex-col gap-4">
              {[
                { id: "hero", label: "Home" },
                { id: "about", label: "About" },
                { id: "portfolio", label: "Portfolio" },
                { id: "why-work", label: "Why Me" },
                { id: "contact", label: "Contact" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={cn(
                    "text-left font-semibold transition-colors duration-300",
                    activeSection === item.id
                      ? "text-blue-600"
                      : "text-slate-700 hover:text-blue-600",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </nav>
        )}
      </header>

      {/* Add padding to body to account for fixed header */}
      <div className="pt-20" />

      {/* Hero Section */}
      <section
        id="hero"
        className="relative w-full min-h-screen flex flex-col items-center justify-center overflow-hidden"
      >
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0 opacity-40"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1599502018635-c1a29c1997f9?w=1600&h=900&fit=crop')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        />

        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-slate-900/85 to-blue-900/90 z-10" />

        {/* Content */}
        <div className="relative z-20 text-center px-6 py-24 md:px-12 md:py-32 max-w-4xl mx-auto">
          <h1
            className={cn(
              "text-5xl md:text-7xl font-black tracking-tighter mb-6 text-white leading-tight flex flex-col",
              inView.hero && "animate-slide-up",
            )}
          >
            Freezing Moments.
            <br />
            <span className="text-blue-400">Living Speed.</span>
          </h1>

          <p className="text-xl md:text-2xl text-blue-200 mb-6 font-light">
            Hockey photography by Maria Mikaelyan
          </p>

          <p className="text-base md:text-lg text-slate-300 mb-10 max-w-2xl mx-auto leading-relaxed">
            Capturing the raw emotion, explosive speed, and unbreakable spirit
            of women's hockey. Every frame tells a story of power,
            determination, and the beautiful chaos of the game.
          </p>

          <button
            onClick={() =>
              document
                .getElementById("portfolio")
                ?.scrollIntoView({ behavior: "smooth" })
            }
            className="inline-block px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white font-bold text-lg rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl"
          >
            View Portfolio
          </button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 animate-bounce">
          <svg
            className="w-6 h-6 text-blue-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="w-full bg-white section-padding">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 items-center">
            {/* Portrait */}
            <div
              className={cn(
                "overflow-hidden rounded-lg",
                inView.about && "animate-slide-up",
              )}
            >
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Fef2a3ecc84fb4e91b8cbf76707786a61%2Fc913783500d44911a236cde390977a11"
                alt="Maria Mikaelyan"
                className="w-full h-auto object-cover aspect-[3/4] hover-lift"
              />
            </div>

            {/* Bio */}
            <div
              className={cn("space-y-6", inView.about && "animate-slide-up")}
            >
              <h2 className="text-4xl md:text-5xl font-black text-slate-900">
                About the
                <br />
                <span className="text-blue-600">Photographer</span>
              </h2>

              <p className="text-base md:text-lg text-slate-700 leading-relaxed">
                I'm Maria Mikaelyan, a passionate hockey photographer dedicated
                to capturing the essence of women's hockey. With years of
                experience shooting live games and tournaments, I've learned
                that the best moments happen in split seconds—when emotions run
                raw, when teams move as one, and when athletes push beyond their
                limits.
              </p>

              <p className="text-base md:text-lg text-slate-700 leading-relaxed">
                My work focuses on real emotion, explosive movement, and the
                unshakeable team spirit that defines women's hockey. I don't
                just document games; I tell stories through images—stories of
                resilience, power, and the beautiful game played at its finest.
              </p>

              <p className="text-base md:text-lg text-slate-700 leading-relaxed">
                Whether it's a game-winning goal, a moment of heartbreak, or the
                quiet determination in a player's eyes, I'm there to freeze that
                moment forever.
              </p>

              <div className="pt-4">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                  Follow on Instagram
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="w-full bg-slate-50 section-padding">
        <div className="max-w-7xl mx-auto">
          <div
            className={cn(
              "text-center mb-16",
              inView.portfolio && "animate-slide-up",
            )}
          >
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">
              Featured
              <br />
              <span className="text-blue-600">Work</span>
            </h2>
            <p className="text-base md:text-lg text-slate-600 max-w-2xl mx-auto">
              A selection of moments captured on the ice—where speed, emotion,
              and excellence meet.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {portfolioItems.map((item, index) => (
              <div
                key={item.id}
                className={cn(
                  "group overflow-hidden rounded-lg shadow-lg hover:shadow-2xl transition-all duration-500",
                  inView.portfolio && "animate-slide-up",
                  item.id === 5 && "flex flex-col",
                )}
                style={{
                  animationDelay: inView.portfolio ? `${index * 100}ms` : "0ms",
                }}
              >
                <div className="relative overflow-hidden aspect-square">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                    <h3 className="text-xl font-bold text-white mb-2">
                      {item.title}
                    </h3>
                    <p className="text-slate-200 text-sm">{item.category}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Work With Me Section */}
      <section id="why-work" className="w-full bg-white section-padding">
        <div className="max-w-6xl mx-auto">
          <div
            className={cn(
              "text-center mb-16",
              inView["why-work"] && "animate-slide-up",
            )}
          >
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">
              Why Work
              <br />
              <span className="text-blue-600">With Me</span>
            </h2>
            <p className="text-base md:text-lg text-slate-600 max-w-2xl mx-auto">
              I bring more than just a camera to every game. I bring passion,
              expertise, and a deep understanding of what makes women's hockey
              special.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {whyWorkItems.map((item, index) => (
              <div
                key={index}
                className={cn(
                  "p-8 rounded-lg bg-slate-50 hover:bg-blue-50 transition-colors duration-300 border border-slate-200 hover:border-blue-300",
                  inView["why-work"] && "animate-slide-up",
                )}
                style={{
                  animationDelay: inView["why-work"]
                    ? `${index * 100}ms`
                    : "0ms",
                }}
              >
                <div className="text-blue-600 mb-4">{item.icon}</div>
                <h3 className="text-xl md:text-2xl font-bold text-slate-900 mb-3">
                  {item.title}
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="w-full bg-slate-900 text-white section-padding"
      >
        <div className="max-w-4xl mx-auto">
          <div
            className={cn(
              "text-center mb-16",
              inView.contact && "animate-slide-up",
            )}
          >
            <h2 className="text-4xl md:text-5xl font-black mb-6">
              Let's Tell Your
              <br />
              <span className="text-blue-400">Story</span>
            </h2>
            <p className="text-base md:text-lg text-slate-300 max-w-2xl mx-auto">
              Teams, organizations, and athletes—your story deserves to be
              captured and celebrated. Let's create images that inspire,
              empower, and last forever.
            </p>
          </div>

          {/* Contact Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <Mail className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-lg font-bold mb-2">Email</h3>
              <a
                href="mailto:maria@hockeyshots.com"
                className="text-slate-300 hover:text-blue-400 transition-colors"
              >
                maria@hockeyshots.com
              </a>
            </div>

            <div className="flex flex-col items-center md:items-start text-center md:text-left">
              <Instagram className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-lg font-bold mb-2">Instagram</h3>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-blue-400 transition-colors"
              >
                @MariaHockeyPhotos
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="space-y-6 mb-16">
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-semibold mb-2"
              >
                Your Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 text-white rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition-all"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label
                htmlFor="email"
                className="block text-sm font-semibold mb-2"
              >
                Your Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 text-white rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition-all"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label
                htmlFor="message"
                className="block text-sm font-semibold mb-2"
              >
                Tell Me About Your Project
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                required
                rows={6}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 text-white rounded-lg focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition-all resize-none"
                placeholder="Tell me about your team or organization..."
              />
            </div>

            <button
              type="submit"
              className="w-full px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white font-bold text-lg rounded-lg transition-all duration-300 hover:scale-105 active:scale-95"
            >
              Send Message
            </button>

            {submitted && (
              <div className="p-4 bg-blue-500/20 border border-blue-500/50 text-blue-200 rounded-lg text-center">
                Thank you! I'll get back to you soon.
              </div>
            )}
          </form>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-700 pt-8 text-center text-slate-400">
          <p>&copy; 2024 Maria Mikaelyan. All rights reserved.</p>
          <p className="text-sm mt-2">
            Hockey photography • Women's sports • Live events
          </p>
        </div>
      </section>
    </div>
  );
}
